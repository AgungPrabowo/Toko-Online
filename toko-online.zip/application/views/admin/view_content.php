<div class="alert alert-block alert-success">
								<button type="button" class="close" data-dismiss="alert">
									<i class="icon-remove"></i>
								</button>

								<i class="icon-ok green"></i>

								Selamat Datang
								<strong class="green">
									Halaman Utama Toko Online Top Tracker
								</strong>
							</div>

							<div class="space-6"></div>